# CiteVerify – six-step paper retrieval + claim assessment update

## Implemented in this build
1. Document parsing/reference extraction runs through the existing analysis pipeline.
2. Each extracted reference is searched in Crossref and OpenAlex (best-effort bibliographic matching).
3. OpenAlex OA locations are discovered; accessible public HTTPS PDF URLs are attempted. Restricted content is not bypassed.
4. Paper results show metadata, abstract, DOI, publisher link, OA link, PDF link, and retrieval status.
5. Downloaded OA PDFs (up to 30 MB) are parsed with PyMuPDF and paragraph passages are surfaced. If no OA PDF can be retrieved, the result remains metadata/abstract-only.
6. Claim assessment is attempted using Groq against retrieved passages, when `GROQ_API_KEY` is set. If no key or no full text is available, the claim remains explicitly pending/Unverifiable rather than fabricating support.

## Run
Backend (CMD):
```bat
cd backend
python -m pip install -r requirements.txt
python -m uvicorn app.main:app --reload --port 8000
```
Frontend (another CMD window):
```bat
npm install
npm run dev
```
If using Groq assessments, set `GROQ_API_KEY` in the backend terminal before starting uvicorn. This build does not bypass publisher paywalls. Retrieval is best-effort and depends on citation quality, network access, and OA availability.

## Test status
Backend tests: 11 passed. Frontend production build was not verified because `npm install` timed out in this environment.
