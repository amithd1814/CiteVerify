# CiteVerify Connected Prototype (fast integration)

## Frontend + backend
The upload workflow already calls the FastAPI backend endpoint `/api/analysis-pipeline` using `fetch` and FormData. This revision adds a document-aware prototype chat after analysis and motion/3D hover transitions.

## Start backend (terminal 1)
```bash
cd backend
python -m pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```
API docs: http://localhost:8000/docs

## Start frontend (terminal 2, project root)
```bash
npm install
npm run dev
```
Use the URL Vite prints (usually localhost:5173 or 5174). CORS is enabled for both ports.

## Honest prototype limits
- Upload/extraction, heuristic claim/citation parsing, reference matching, and metadata discovery connect to backend endpoints.
- Ask CiteVerify is a local document-aware prototype response panel, not an LLM; answers only describe extracted counts and pipeline limitations.
- Research discovery is metadata, not full-text claim verification. No claim is marked supported by this prototype.
- The motion effects are CSS 3D depth/hover/entrance animations, not a WebGL 3D scene.
