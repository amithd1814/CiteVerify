from __future__ import annotations
import re
from typing import Any


def normalize(text: str) -> str:
    text = re.sub(r'[^a-z0-9]+', ' ', text.lower())
    return re.sub(r'\s+', ' ', text).strip()


def _tokens(text: str) -> set[str]:
    return {t for t in normalize(text).split() if len(t) > 2}


def match_citations_to_references(citations: list[dict[str, Any]], references: list[str]) -> list[dict[str, Any]]:
    """Style-agnostic baseline matching. Scores lexical overlap and DOI/title signals."""
    out=[]
    ref_tokens=[_tokens(r) for r in references]
    for citation in citations:
        raw=citation.get('text','')
        c_norm=normalize(raw)
        best_idx=-1; best_score=0.0
        for idx,ref in enumerate(references):
            r_norm=normalize(ref)
            score=0.0
            if c_norm and c_norm in r_norm: score=1.0
            elif c_norm.startswith('10.') and c_norm in r_norm: score=1.0
            else:
                c_tokens=_tokens(raw)
                if c_tokens and ref_tokens[idx]:
                    overlap=len(c_tokens & ref_tokens[idx])
                    score=overlap / max(1, len(c_tokens))
            if score>best_score: best_score=score; best_idx=idx
        threshold=0.45 if citation.get('style_detected')=='author_year' else 0.5
        matched=best_idx>=0 and best_score>=threshold
        out.append({**citation,'matched_reference_index':best_idx if matched else None,
                   'matched_reference':references[best_idx] if matched else None,
                   'match_score':round(best_score,3),'match_status':'matched' if matched else 'unmatched'})
    return out
