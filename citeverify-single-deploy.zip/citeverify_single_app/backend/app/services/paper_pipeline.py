from __future__ import annotations
import re, requests, fitz
from typing import Any
from app.services.research_lookup import search_research, discover_open_access

UA={'User-Agent':'CiteVerify/0.1 (open-access paper retrieval prototype)'}

def _get_text_pdf(url: str, timeout: int=18) -> tuple[str,str|None]:
    if not url or not url.lower().startswith('https://'): return '', 'Only HTTPS OA URLs are attempted.'
    try:
        r=requests.get(url,headers=UA,timeout=timeout,stream=True)
        r.raise_for_status()
        content_type=r.headers.get('Content-Type','').lower()
        data=r.content
        if len(data)>30*1024*1024: return '', 'PDF exceeds 30 MB retrieval limit.'
        if 'pdf' not in content_type and not data.startswith(b'%PDF'): return '', 'URL did not return a PDF.'
        with fitz.open(stream=data,filetype='pdf') as doc:
            return '\n'.join(p.get_text('text') for p in doc), None
    except Exception as e:
        return '', f'Full text retrieval failed ({type(e).__name__}).'

def retrieve_reference(reference: str, limit:int=3) -> dict[str,Any]:
    query=reference.strip()
    result=search_research(query,limit=limit)
    papers=[]
    for item in result.get('results',[])[:limit]:
        doi=item.get('doi') or ''
        oa=discover_open_access(doi or item.get('title') or query) if (doi or item.get('title')) else {'status':'not_found','open_access_locations':[]}
        locations=oa.get('open_access_locations') or []
        full_text=''; full_text_error=None; retrieved_from=None
        for loc in locations:
            pdf=loc.get('pdf_url')
            if pdf:
                full_text,full_text_error=_get_text_pdf(pdf)
                if full_text.strip(): retrieved_from=pdf; break
        passages=[]
        if full_text:
            # Split into text paragraphs, keep readable passages; no verdict is inferred here.
            paras=[re.sub(r'\s+',' ',p).strip() for p in re.split(r'\n\s*\n',full_text) if len(re.sub(r'\s+',' ',p).strip())>100]
            passages=paras[:20]
        papers.append({**item,'open_access_status':oa.get('status'),'open_access_locations':locations,
          'full_text_retrieved':bool(full_text),'full_text_url':retrieved_from,'full_text_error':full_text_error,
          'passages':passages,'full_text_characters':len(full_text)})
    return {'reference':query,'papers':papers,'search_errors':result.get('errors',[]),'retrieval_note':'Full text is only extracted from accessible public OA PDF URLs. Metadata/abstract-only results are not treated as full-text evidence.'}

def retrieve_references(references:list[str], max_refs:int=12) -> dict[str,Any]:
    items=[]
    for ref in references[:max_refs]:
        if not str(ref).strip(): continue
        items.append(retrieve_reference(str(ref),limit=3))
    return {'references_processed':len(items),'items':items,'note':'Search and full-text retrieval are best-effort. No paywalls are bypassed.'}

def assess_claims(claims:list[dict], retrieval:dict) -> list[dict]:
    """LLM assessment against retrieved passages only; otherwise returns explicit pending statuses."""
    import os, json
    key=os.getenv('GROQ_API_KEY','').strip()
    if not key:
        return [{'claim':c.get('text') or c.get('claim'),'status':'Pending evidence assessment','reason':'GROQ_API_KEY is not configured; no automated claim comparison was run.','evidence':[]} for c in claims]
    paper_context=[]
    for group in retrieval.get('items',[]):
        for paper in group.get('papers',[]):
            if paper.get('full_text_retrieved'):
                paper_context.append({'paper':paper.get('title'),'doi':paper.get('doi'),'passages':paper.get('passages',[])[:8]})
    if not paper_context:
        return [{'claim':c.get('text') or c.get('claim'),'status':'Unverifiable','reason':'No retrieved full-text passages were available to assess this claim.','evidence':[]} for c in claims]
    output=[]
    for claim in claims[:60]:
        text=claim.get('text') or claim.get('claim') or ''
        prompt={'claim':text,'retrieved_papers':paper_context[:12]}
        try:
            r=requests.post('https://api.groq.com/openai/v1/chat/completions',headers={'Authorization':'Bearer '+key,'Content-Type':'application/json'},json={'model':os.getenv('GROQ_MODEL','llama-3.3-70b-versatile'),'messages':[{'role':'system','content':'Assess the claim strictly against the supplied extracted full-text passages. Never use general knowledge. If evidence is insufficient, return Unverifiable. Use statuses Supported, Partially supported, Unsupported, Contradicted, or Unverifiable. Return valid JSON with status, reason, and evidence (array of exact short quotes). Do not invent quotes.'},{'role':'user','content':json.dumps(prompt,ensure_ascii=False)}],'temperature':0.1,'max_tokens':500},timeout=30)
            r.raise_for_status(); raw=r.json()['choices'][0]['message']['content']; raw=re.sub(r'^```(?:json)?|```$','',raw.strip(),flags=re.I).strip(); obj=json.loads(raw)
            status=obj.get('status','Unverifiable'); allowed={'Supported','Partially supported','Unsupported','Contradicted','Unverifiable'}
            if status not in allowed: status='Unverifiable'
            output.append({'claim':text,'status':status,'reason':str(obj.get('reason',''))[:1500],'evidence':obj.get('evidence',[])})
        except Exception as e:
            output.append({'claim':text,'status':'Unverifiable','reason':f'Automated assessment failed ({type(e).__name__}); human review required.','evidence':[]})
    return output
