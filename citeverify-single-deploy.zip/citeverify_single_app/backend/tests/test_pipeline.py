from app.services.pipeline import build_analysis


def test_pipeline_conservative_verdicts_and_document_metadata():
    pages=[{'page':1,'text':'The treatment is associated with improved outcomes in this sample, according to the researchers. [1]\n\nReferences\n[1] Example Author. Example Study. 2020. https://doi.org/10.1234/example'}]
    result=build_analysis(pages,'paper.txt','abc123','txt')
    assert result['document']['document_id']=='abc123'
    assert result['document']['reference_section_detected'] is True
    assert result['citations']
    assert result['references']
    assert all(c['verdict']=='Unverifiable' for c in result['claims'])
    assert all('No source full text' in c['verdict_reason'] for c in result['claims'])


def test_report_builder_handles_pipeline_claim_key():
    from app.services.report_builder import build_report, report_markdown
    claim={'claim_id':'c1','claim':'A concrete test claim is presented here.','verdict':'Unverifiable','evidence':[]}
    report=build_report({'filename':'test.txt'},[claim])
    markdown=report_markdown(report)
    assert claim['claim'] in markdown
    assert report['summary']['report_status']=='draft_pending_human_review'
