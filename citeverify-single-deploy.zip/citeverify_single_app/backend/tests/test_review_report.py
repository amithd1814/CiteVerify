import tempfile
from pathlib import Path
from app.services import review_store
from app.services.report_builder import build_report, report_markdown

def test_review_actions_and_report(monkeypatch):
    tmp=Path(tempfile.mkdtemp())/'reviews.sqlite3'
    monkeypatch.setattr(review_store,'DB_PATH',tmp)
    session=review_store.create_review('r1','doc1',{'claims':[{'claim_id':'c1','text':'Claim','verdict':'Unverifiable'}]})
    updated=review_store.update_review('r1','Reviewer','c1','modify_verdict',{'verdict':'Partially supported','comment':'Needs nuance'})
    assert updated['payload']['claims'][0]['human_verdict']=='Partially supported'
    review_store.update_review('r1','Reviewer',None,'approve_report',{})
    loaded=review_store.get_review('r1')
    report=build_report({'filename':'test.pdf','document_id':'doc1'},loaded['payload']['claims'],loaded)
    assert report['summary']['human_approved'] is True
    assert report['summary']['report_status']=='human_verified'
    assert 'Claim review' in report_markdown(report)
